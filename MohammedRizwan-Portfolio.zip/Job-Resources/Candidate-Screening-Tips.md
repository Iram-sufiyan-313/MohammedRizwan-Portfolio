# Candidate Screening Tips

1. Review resume for relevant skills and experience
2. Check availability for H1B, OPT, CPT candidates
3. Conduct brief phone/virtual interview to assess communication
4. Shortlist based on client requirements and skill alignment
5. Keep detailed notes for vendor/client updates