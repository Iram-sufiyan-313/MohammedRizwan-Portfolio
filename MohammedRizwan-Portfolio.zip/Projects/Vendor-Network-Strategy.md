# Vendor Network Strategy

Steps to build and scale a successful vendor network:

1. Identify potential vendors
2. Establish communication and build relationships
3. Maintain a database with contact and performance metrics
4. Regularly update vendors on available candidates
5. Track submissions and placements