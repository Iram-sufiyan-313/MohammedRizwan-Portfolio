# Recruitment Process Demo

This file demonstrates a sample recruitment workflow:

1. Candidate Sourcing
2. Screening & Shortlisting
3. Interview Coordination
4. Vendor/Client Communication
5. Offer & Onboarding